import cv2 as cv
import sys

name = input("Name: ")
bd = input("Birth Date: ")
mbti = input("MBTI: ")
position = input("Watermark position(top-left/top-right/bottom-left/bottom-right): ")

img=cv.imread('KimSehui_2021116864.jpg')

if img is None:
    sys.exit('No image')

height, width = img.shape[:2]

texts = [name, bd, mbti]


if position.lower() == "top-left":
    x, y_start = 20, 40
    
elif position.lower() == "top-right":
    x = width - 20
    y_start = 40
    
elif position.lower() == "bottom-left":
    x, y_start = 20, height - 30 * len(texts)
    
elif position.lower() == "bottom-right":
    x = width - 20
    y_start = height - 30 * len(texts)
    
else:
    sys.exit("Use top-left, top-right, bottom-left, or bottom-right.")

for i, text in enumerate(texts):
    (text_width, text_height), _ = cv.getTextSize(text, cv.FONT_HERSHEY_SIMPLEX, 0.7, 2)
    y = y_start + i * 30

    if position.lower().endswith("right"):
        x = width - text_width - 20

    cv.putText(img, text, (x, y), cv.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

cv.imwrite('Watermarked_KimSehui.jpg', img)

watermarked_img = cv.imread('Watermarked_KimSehui.jpg')
if watermarked_img is None:
    sys.exit('No watermarked image')

cv.imshow("wartermarked_image", watermarked_img)

cv.waitKey()
cv.destroyAllWindows()
