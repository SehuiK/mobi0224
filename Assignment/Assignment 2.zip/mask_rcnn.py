import torch
from torchvision.models.detection import maskrcnn_resnet50_fpn, MaskRCNN_ResNet50_FPN_Weights
from torchvision.transforms import functional as F
import cv2 as cv
import sys
import numpy as np
import matplotlib.pyplot as plt
import random

def load_image(image_path):
    image = cv.imread(image_path)
    if image is None:
        sys.exit(f"Failed to read image from {image_path}")
    image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
    image_tensor = F.to_tensor(image)
    return image_tensor

def detect_objects(model, image_tensor):
    model.eval()
    with torch.no_grad():
        predictions = model([image_tensor])
    return predictions[0]

def generate_random_colors(num_colors):
    colors = []
    for _ in range(num_colors):
        colors.append((random.random(), random.random(), random.random()))
    return colors

def plot_image_with_masks(image_tensor, predictions, title, file_path):
    image_np = image_tensor.mul(255).permute(1, 2, 0).byte().numpy()
    plt.figure(figsize=(12, 8))
    plt.imshow(image_np)
    plt.title(title)
    
    masks = predictions['masks'] > 0.5
    colors = generate_random_colors(len(predictions['boxes']))
    
    for mask, bbox, score, color in zip(masks, predictions['boxes'], predictions['scores'], colors):
        if score >= 0.5:
            mask_np = mask.squeeze().numpy()
            color_img = np.zeros_like(image_np)
            color_img[:, :, 0] = color[0] * 255
            color_img[:, :, 1] = color[1] * 255
            color_img[:, :, 2] = color[2] * 255
            plt.imshow(np.where(mask_np[:, :, None], color_img, 0), alpha=0.5)

            x1, y1, x2, y2 = bbox
            plt.gca().add_patch(plt.Rectangle((x1, y1), x2-x1, y2-y1, fill=False, color=color, linewidth=3))
            plt.gca().text(x1, y1, f'Score: {score:.2f}', bbox=dict(facecolor='yellow', alpha=0.5))
    
    plt.axis('off')
    plt.savefig(file_path)
    plt.show()
    plt.close()

# 모델 로드
model = maskrcnn_resnet50_fpn(weights=MaskRCNN_ResNet50_FPN_Weights.DEFAULT)

# 이미지 로드
bottom_right_image_path = 'bottom_right_KimSehui.jpg'
original_image_path = 'KimSehui_2021116864.jpg'

bottom_right_image = load_image(bottom_right_image_path)
original_image = load_image(original_image_path)

# 객체 탐지 및 세그멘테이션 실행
bottom_right_predictions = detect_objects(model, bottom_right_image)
original_predictions = detect_objects(model, original_image)

# 결과 저장 및 표시
bottom_right_save_path = 'detected_bottom_right_KimSehui.jpg'
original_save_path = 'detected_original_image.jpg'

plot_image_with_masks(bottom_right_image, bottom_right_predictions, "Watermarked(bottom_right) Image Detection", bottom_right_save_path)
plot_image_with_masks(original_image, original_predictions, "Original Image Detection", original_save_path)
